# Savage Roast Bot

A sarcastic, verbally abusive fake AI Discord bot.
Type `!ask` followed by your question, and the bot will roast you instead of answering.

## Setup

1. Clone this repo or copy the files.
2. Install dependencies:

```
pip install -r requirements.txt
```

3. Replace `YOUR_DISCORD_BOT_TOKEN` in `main.py` with your bot token.
4. Run the bot:

```
python main.py
```

## Usage

In Discord, type:

```
!ask [your question]
```

Example:

```
!ask Why is water wet?
```

And brace for impact. The bot will roast you like a seasoned stand-up comic.
